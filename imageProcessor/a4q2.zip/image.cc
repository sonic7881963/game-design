#include "image.h"  

Image::~Image(){}
